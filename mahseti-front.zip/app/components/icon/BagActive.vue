<template>
   
<svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.2 8.66699H20.8C25.3334 8.66699 25.7867 10.787 26.0934 13.3737L27.2934 23.3737C27.68 26.6537 26.6667 29.3337 22 29.3337H10.0134C5.33337 29.3337 4.32003 26.6537 4.72003 23.3737L5.92004 13.3737C6.21338 10.787 6.6667 8.66699 11.2 8.66699Z" stroke="#72B742" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10.667 10.667V6.00033C10.667 4.00033 12.0003 2.66699 14.0003 2.66699H18.0003C20.0003 2.66699 21.3337 4.00033 21.3337 6.00033V10.667" stroke="#72B742" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M27.2137 22.707H10.667" stroke="#72B742" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>

</template>
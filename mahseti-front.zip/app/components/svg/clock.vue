<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
        <path
            d="M18.3327 9.99935C18.3327 14.5993 14.5993 18.3327 9.99935 18.3327C5.39935 18.3327 1.66602 14.5993 1.66602 9.99935C1.66602 5.39935 5.39935 1.66602 9.99935 1.66602C14.5993 1.66602 18.3327 5.39935 18.3327 9.99935Z"
            stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
        <path d="M13.0914 12.6495L10.5081 11.1078C10.0581 10.8411 9.69141 10.1995 9.69141 9.67448V6.25781"
            stroke="#72B742" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
</template>
<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
        <path d="M12 6.33301L8 10.333L4 6.33301H12Z" fill="black" stroke="black" stroke-width="2"
            stroke-linejoin="round" />
    </svg>
</template>
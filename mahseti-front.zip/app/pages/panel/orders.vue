<template>
  <div class="p-8 border rounded-inner shadow">
    <h3 class="font-bold text-xl  pb-4 mb-4 border-b">سفارش ها</h3>

    <div v-if="!ordersData" class="text-center py-8">
      <SharedLoadingSpinner size="lg" />
    </div>

    <div v-else-if="orders.length === 0" class="text-center py-8">
      <p class="text-muted">هیچ سفارشی یافت نشد</p>
    </div>

    <div v-else v-for="order in orders" :key="order.id"
      class="border rounded-inner p-4 mx-auto shadow flex flex-col gap-4 bg-primary mb-4">
      <!-- بالای کارت: وضعیت + بستن -->
      <div class="flex justify-between items-center">
        <div class="flex items-center gap-2">
          <component :is="getStatusIcon(order.status)" class="w-5 h-5 text-gray-600" />
          <span :class="getStatusColor(order.status)">{{
            getStatusText(order.status)
          }}</span>

          <span v-if="order.status=='reserved'" class="font-bold text-green-950">
            نگه داشته شده تا تاریخ:{{ new Date(order.reserved_until).toLocaleDateString('fa') }}
          </span>
        </div>
        <nuxt-link :to="`order/${order.id}`" class="text-muted">
          <ChevronLeft />
        </nuxt-link>
      </div>

      <!-- اطلاعات سفارش -->
      <div class="flex items-center text-sm text-muted gap-3 border-b pb-4">
        <span>{{ order.date }}</span>
        <span class="w-2 h-2 bg-accent rounded-full"></span>
        <span>کد سفارش: <span class="font-semibold">{{ order.id }}</span></span>
        <span class="w-2 h-2 bg-accent rounded-full"></span>
        <span>مبلغ:
          <span class="font-semibold">{{ order.total?.toLocaleString() }} تومان</span></span>
      </div>

      <!-- محصول -->
      <div v-if="order.items.length" class="flex items-center gap-4">
        <img :src="$getImageUrl(order.items[0].product.main_image)" class="w-16 h-16 rounded" />
        <div class="flex flex-col gap-3">
          <span class="font-semibold text-sm">{{ order.items[0].product.title }}</span>
        </div>
      </div>
    </div>
  </div>
</template>




<script setup>
import { useApi } from '@/composables/api/useApi'
const { $getImageUrl } = useNuxtApp();

definePageMeta({
  layout: "panel",
  middleware: 'auth'
});

import {
  X,
  CheckCircle,
  Clock,
  AlertCircle,
  Disc,
  ChevronLeft,
} from "lucide-vue-next";
import { ref } from "vue";

const { getOrders } = useApi()

// دریافت سفارشات از API
const { data: ordersData } = await useAsyncData(
  'userOrders',
  async () => {
    try {
      return await getOrders()
    } catch (error) {
      console.error('❌ Failed to fetch orders:', error)
      return { data: [] }
    }
  },
  {
    lazy: true,
    server: false
  }
)

// استفاده از داده‌های API
const orders = computed(() => ordersData.value?.orders || []);

function getStatusIcon(status) {
  switch (status) {
    case "cancelled":
      return AlertCircle;
    case "failed":
      return AlertCircle;
    case "pending":
      return Clock;
    case "delivered":
      return CheckCircle;
    default:
      return Clock;
  }
}
function getStatusText(status) {
  switch (status) {
    case "card_transfer_pending":
      return "در انتظار آپلود رسید";
    case "card_transfer_review":
      return "در حال پردازش رسید";
    case "card_transfer_send_again":
      return "در انتظار آپلود مجدد رسید";
    case "cancelled":
      return "لغو شده";
    case "failed":
      return "لغو شده";

    case "pending":
      return "در حال بررسی";
    case "delivered":
      return "تحویل داده شد";
    case "paid":
      return "پرداخت شده";
    case "completed":
      return "تکمیل شده";
    case "reserved":
      return "رزرو شده";
    default:
      return "نامشخص";
  }
}


function getStatusColor(status) {
  switch (status) {
    case "cancelled":
      return "text-red";
    case "failed":
      return "text-red";
    case "pending":
      return "text-gold";
    case "delivered":
      return "text-strong";
    default:
      return "text-muted";
  }
}
</script>

<style scoped>
/* استفاده از کلاس‌های CSS شما برای rounded و shadow */
</style>

import{_ as e}from"./DlAUqK2U.js";import{c as o,o as r}from"./V1YFE3ng.js";const c={};function t(n,_){return r(),o("div")}const f=e(c,[["render",t]]);export{f as default};

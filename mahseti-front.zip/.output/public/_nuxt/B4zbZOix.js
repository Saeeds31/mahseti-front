import{E as s}from"./L9Ibf1oN.js";const t=s("/icons/heart.svg"),a=s("/icons/bag.svg");export{t as _,a};

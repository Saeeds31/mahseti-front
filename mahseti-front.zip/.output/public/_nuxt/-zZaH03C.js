import{_ as e}from"./DlAUqK2U.js";import{c as o,o as r}from"./puf8Vmu9.js";const c={};function t(n,_){return r(),o("div")}const f=e(c,[["render",t]]);export{f as default};

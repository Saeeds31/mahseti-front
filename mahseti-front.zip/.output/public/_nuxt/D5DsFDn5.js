import{_ as r}from"./DlAUqK2U.js";const e={};function c(t,o){return" searchLoader "}const _=r(e,[["render",c]]);export{_ as default};

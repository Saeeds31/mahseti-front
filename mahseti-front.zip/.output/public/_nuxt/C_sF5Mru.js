import{E as s}from"./V1YFE3ng.js";const t=s("/icons/heart.svg"),a=s("/icons/bag.svg");export{t as _,a};

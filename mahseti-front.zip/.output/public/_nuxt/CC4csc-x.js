import{a2 as e,_ as a,z as o,A as n}from"./L9Ibf1oN.js";const i=e(l=>{if(!localStorage.getItem("auth-token"))return a(()=>{const t=o("loginModal");t.value=!0}),n("/")});export{i as default};

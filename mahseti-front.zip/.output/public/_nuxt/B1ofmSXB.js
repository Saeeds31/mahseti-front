import{E as s}from"./puf8Vmu9.js";const t=s("/icons/heart.svg"),a=s("/icons/bag.svg");export{t as _,a};

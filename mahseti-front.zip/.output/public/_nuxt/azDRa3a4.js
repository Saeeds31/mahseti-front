import{_ as e}from"./DlAUqK2U.js";import{c as o,o as r}from"./V1YFE3ng.js";const c={};function n(t,a){return r(),o("div",null," dashboard ")}const d=e(c,[["render",n]]);export{d as default};

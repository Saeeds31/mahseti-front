import{_ as e}from"./DlAUqK2U.js";import{c as o,o as r}from"./L9Ibf1oN.js";const c={};function t(n,_){return r(),o("div")}const f=e(c,[["render",t]]);export{f as default};

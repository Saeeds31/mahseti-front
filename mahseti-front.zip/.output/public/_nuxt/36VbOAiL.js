import{E as s}from"./WIenMseI.js";const t=s("/icons/heart.svg"),a=s("/icons/bag.svg");export{t as _,a};

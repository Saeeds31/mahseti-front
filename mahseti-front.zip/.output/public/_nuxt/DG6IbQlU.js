import{E as s}from"./CxF2zy_X.js";const t=s("/icons/heart.svg"),a=s("/icons/bag.svg");export{t as _,a};

import{c as s}from"./DYGgVb_o.js";const c=s("minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{c as M};
